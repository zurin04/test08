import { Switch, Route } from "wouter";
import { QueryClientProvider } from "@tanstack/react-query";
import { queryClient } from "./lib/queryClient";
import { Toaster } from "@/components/ui/toaster";
import { AuthProvider } from "@/hooks/use-auth";
import { GlobalChatProvider } from "@/hooks/use-global-chat";
import { ThemeProvider } from "@/hooks/use-theme";
import { I18nProvider } from "@/hooks/use-i18n";
import { useFavicon } from "@/hooks/use-favicon";
import { useAnalytics, initGA } from "@/hooks/use-analytics";
import { useEffect } from "react";
import AnnouncementBanner from "@/components/ui/announcement-banner";
import NewsTicker from "@/components/ui/news-ticker";

// Components
import HomePage from "@/pages/home-page";
import AirdropsPage from "@/pages/airdrops-page";
import AirdropDetails from "@/pages/airdrop-details";
import ChatPage from "@/pages/chat-page";
import NotFound from "@/pages/not-found";
import AuthPage from "@/pages/auth-page";
import ProfilePage from "@/pages/profile-page";
import CreateAirdropPage from "@/pages/create-airdrop";
import EditAirdropPage from "@/pages/edit-airdrop";
import MembersPage from "@/pages/members-page";
import CreatorTimeline from "@/pages/creator-timeline";
import ChangePassword from "@/pages/change-password";
import AnnouncementsPage from "@/pages/announcements-page";
import UserDashboard from "@/pages/user-dashboard";
import PostNewsPage from "@/pages/post-news";
import CreatePostPage from "@/pages/create-post";

// Legal Pages
import PrivacyPolicy from "@/pages/privacy-policy";
import TermsOfService from "@/pages/terms-of-service";
import CookiePolicy from "@/pages/cookie-policy";
import Disclaimer from "@/pages/disclaimer";

// Additional Pages
import FAQ from "@/pages/faq";
import CommunityRules from "@/pages/community-rules";
import AboutUs from "@/pages/about-us";
import Settings from "@/pages/settings";

// Admin Pages
import AdminDashboardPage from "@/pages/admin/dashboard";
import AdminCreateAirdropPage from "@/pages/admin/create-airdrop";
import AdminEditAirdropPage from "@/pages/admin/edit-airdrop";
import CreatorApplicationsPage from "@/pages/admin/creator-applications";

// Protected Routes
import { ProtectedRoute } from "@/lib/protected-route";
import { AdminRoute } from "@/lib/admin-route";

// Wrapper component for edit airdrop route
function EditAirdropWrapper({ params }: { params: { id: string } }) {
  return <EditAirdropPage airdropId={params.id} />;
}

function Router() {
  return (
    <>
      <AnnouncementBanner />
      <NewsTicker />
      <Switch>
      <Route path="/" component={HomePage} />
      <Route path="/airdrops" component={AirdropsPage} />
      <Route path="/airdrops/category/:categoryId" component={AirdropsPage} />
      <Route path="/airdrop/:id" component={AirdropDetails} />
      <Route path="/chat" component={ChatPage} />
      <Route path="/announcements" component={AnnouncementsPage} />
      <Route path="/members" component={MembersPage} />
      <Route path="/creator-timeline/:username" component={CreatorTimeline} />
      <Route path="/auth" component={AuthPage} />
      <ProtectedRoute path="/dashboard" component={() => <UserDashboard />} />
      <ProtectedRoute path="/profile" component={() => <ProfilePage />} />
      <ProtectedRoute path="/change-password" component={() => <ChangePassword />} />
      <ProtectedRoute path="/create-airdrop" component={() => <CreateAirdropPage />} />
      <ProtectedRoute path="/create-post" component={() => <CreatePostPage />} />
      <AdminRoute path="/post-news" component={() => <PostNewsPage />} />
      <Route path="/airdrops/edit/:id" component={EditAirdropWrapper} />
      
      {/* Admin Routes */}
      <AdminRoute path="/admin" component={() => <AdminDashboardPage />} />
      <AdminRoute path="/admin/airdrops/create" component={() => <AdminCreateAirdropPage />} />
      <AdminRoute path="/admin/airdrops/edit/:id" component={() => <AdminEditAirdropPage />} />
      <AdminRoute path="/admin/creator-applications" component={() => <CreatorApplicationsPage />} />
      <AdminRoute path="/admin/members" component={() => <MembersPage />} />
      
      {/* Additional Pages */}
      <Route path="/faq" component={FAQ} />
      <Route path="/community-rules" component={CommunityRules} />
      <Route path="/about-us" component={AboutUs} />
      <ProtectedRoute path="/settings" component={() => <Settings />} />
      
      {/* Legal Pages */}
      <Route path="/privacy-policy" component={PrivacyPolicy} />
      <Route path="/terms-of-service" component={TermsOfService} />
      <Route path="/cookie-policy" component={CookiePolicy} />
      <Route path="/disclaimer" component={Disclaimer} />
      
      {/* Fallback to 404 */}
      <Route component={NotFound} />
    </Switch>
    </>
  );
}

// Component to handle favicon updates inside QueryClient context
function FaviconHandler() {
  useFavicon();
  return null;
}

// Component to initialize analytics
function AnalyticsHandler() {
  useAnalytics();
  
  // Initialize Google Analytics when app loads
  useEffect(() => {
    if (!import.meta.env.VITE_GA_MEASUREMENT_ID) {
      console.warn('Missing Google Analytics key: VITE_GA_MEASUREMENT_ID');
    } else {
      initGA();
    }
  }, []);
  
  return null;
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <ThemeProvider defaultTheme="dark" storageKey="vite-ui-theme">
        <I18nProvider>
          <FaviconHandler />
          <AuthProvider>
            <GlobalChatProvider>
              <AnalyticsHandler />
              <Router />
              <Toaster />
            </GlobalChatProvider>
          </AuthProvider>
        </I18nProvider>
      </ThemeProvider>
    </QueryClientProvider>
  );
}

export default App;
