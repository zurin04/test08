import { createContext, useContext, useState, useEffect, ReactNode } from 'react';

interface Translations {
  [key: string]: string;
}

interface Language {
  code: string;
  name: string;
  flag: string;
}

interface I18nContextType {
  language: string;
  setLanguage: (lang: string) => void;
  t: (key: string, params?: Record<string, string>) => string;
  languages: Language[];
}

const I18nContext = createContext<I18nContextType | undefined>(undefined);

const languages: Language[] = [
  { code: 'en', name: 'English', flag: '🇺🇸' },
  { code: 'es', name: 'Español', flag: '🇪🇸' },
  { code: 'fr', name: 'Français', flag: '🇫🇷' },
  { code: 'de', name: 'Deutsch', flag: '🇩🇪' },
  { code: 'zh', name: '中文', flag: '🇨🇳' },
  { code: 'ja', name: '日本語', flag: '🇯🇵' },
  { code: 'ko', name: '한국어', flag: '🇰🇷' },
  { code: 'ru', name: 'Русский', flag: '🇷🇺' },
];

// Default translations
const translations: Record<string, Translations> = {
  en: {
    'nav.home': 'Home',
    'nav.airdrops': 'Airdrops',
    'nav.chat': 'Chat',
    'nav.dashboard': 'Dashboard',
    'nav.profile': 'Profile',
    'auth.login': 'Login',
    'auth.register': 'Register',
    'auth.logout': 'Logout',
    'search.placeholder': 'Search airdrops...',
    'filter.all': 'All',
    'filter.active': 'Active',
    'filter.completed': 'Completed',
    'button.save': 'Save',
    'button.cancel': 'Cancel',
    'button.submit': 'Submit',
    'status.loading': 'Loading...',
    'status.error': 'Error occurred',
    'status.success': 'Success',
    'airdrop.views': 'views',
    'airdrop.completed': 'Completed',
    'airdrop.save': 'Save',
    'dashboard.stats': 'Statistics',
    'dashboard.saved': 'Saved',
    'dashboard.completed': 'Completed',
    'profile.edit': 'Edit Profile',
    'profile.settings': 'Settings',
  },
  es: {
    'nav.home': 'Inicio',
    'nav.airdrops': 'Airdrops',
    'nav.chat': 'Chat',
    'nav.dashboard': 'Panel',
    'nav.profile': 'Perfil',
    'auth.login': 'Iniciar Sesión',
    'auth.register': 'Registrarse',
    'auth.logout': 'Cerrar Sesión',
    'search.placeholder': 'Buscar airdrops...',
    'filter.all': 'Todos',
    'filter.active': 'Activos',
    'filter.completed': 'Completados',
    'button.save': 'Guardar',
    'button.cancel': 'Cancelar',
    'button.submit': 'Enviar',
    'status.loading': 'Cargando...',
    'status.error': 'Error ocurrido',
    'status.success': 'Éxito',
    'airdrop.views': 'vistas',
    'airdrop.completed': 'Completado',
    'airdrop.save': 'Guardar',
    'dashboard.stats': 'Estadísticas',
    'dashboard.saved': 'Guardados',
    'dashboard.completed': 'Completados',
    'profile.edit': 'Editar Perfil',
    'profile.settings': 'Configuración',
  },
  zh: {
    'nav.home': '首页',
    'nav.airdrops': '空投',
    'nav.chat': '聊天',
    'nav.dashboard': '仪表板',
    'nav.profile': '个人资料',
    'auth.login': '登录',
    'auth.register': '注册',
    'auth.logout': '登出',
    'search.placeholder': '搜索空投...',
    'filter.all': '全部',
    'filter.active': '活跃',
    'filter.completed': '已完成',
    'button.save': '保存',
    'button.cancel': '取消',
    'button.submit': '提交',
    'status.loading': '加载中...',
    'status.error': '发生错误',
    'status.success': '成功',
    'airdrop.views': '浏览',
    'airdrop.completed': '已完成',
    'airdrop.save': '保存',
    'dashboard.stats': '统计',
    'dashboard.saved': '已保存',
    'dashboard.completed': '已完成',
    'profile.edit': '编辑资料',
    'profile.settings': '设置',
  },
};

export function I18nProvider({ children }: { children: ReactNode }) {
  const [language, setLanguageState] = useState(() => {
    const saved = localStorage.getItem('preferred-language');
    if (saved && translations[saved]) return saved;
    
    // Detect browser language
    const browserLang = navigator.language.split('-')[0];
    return translations[browserLang] ? browserLang : 'en';
  });

  const setLanguage = (lang: string) => {
    if (translations[lang]) {
      setLanguageState(lang);
      localStorage.setItem('preferred-language', lang);
      document.documentElement.lang = lang;
    }
  };

  const t = (key: string, params?: Record<string, string>): string => {
    let translation = translations[language]?.[key] || translations.en[key] || key;
    
    if (params) {
      Object.entries(params).forEach(([param, value]) => {
        translation = translation.replace(`{{${param}}}`, value);
      });
    }
    
    return translation;
  };

  useEffect(() => {
    document.documentElement.lang = language;
  }, [language]);

  return (
    <I18nContext.Provider value={{ language, setLanguage, t, languages }}>
      {children}
    </I18nContext.Provider>
  );
}

export function useI18n() {
  const context = useContext(I18nContext);
  if (!context) {
    throw new Error('useI18n must be used within an I18nProvider');
  }
  return context;
}