import { useEffect, useRef } from 'react';
import { useLocation } from 'wouter';

// Define the gtag function globally
declare global {
  interface Window {
    dataLayer: any[];
    gtag: (...args: any[]) => void;
  }
}

// Initialize Google Analytics
export const initGA = () => {
  const measurementId = import.meta.env.VITE_GA_MEASUREMENT_ID;

  if (!measurementId) {
    console.warn('Missing required Google Analytics key: VITE_GA_MEASUREMENT_ID');
    return;
  }

  // Add Google Analytics script to the head
  const script1 = document.createElement('script');
  script1.async = true;
  script1.src = `https://www.googletagmanager.com/gtag/js?id=${measurementId}`;
  document.head.appendChild(script1);

  // Initialize gtag
  const script2 = document.createElement('script');
  script2.innerHTML = `
    window.dataLayer = window.dataLayer || [];
    function gtag(){dataLayer.push(arguments);}
    gtag('js', new Date());
    gtag('config', '${measurementId}');
  `;
  document.head.appendChild(script2);
};

// Track page views - useful for single-page applications
export const trackPageView = (url: string) => {
  if (typeof window === 'undefined' || !window.gtag) return;
  
  const measurementId = import.meta.env.VITE_GA_MEASUREMENT_ID;
  if (!measurementId) return;
  
  window.gtag('config', measurementId, {
    page_path: url
  });
};

// Track events
export const trackEvent = (
  action: string, 
  category?: string, 
  label?: string, 
  value?: number
) => {
  if (typeof window === 'undefined' || !window.gtag) return;
  
  window.gtag('event', action, {
    event_category: category,
    event_label: label,
    value: value,
  });
};

// Track user engagement events
export const trackUserEngagement = {
  airdropView: (airdropId: number, title: string) => {
    trackEvent('view_airdrop', 'engagement', title, airdropId);
  },
  
  airdropSave: (airdropId: number, title: string) => {
    trackEvent('save_airdrop', 'engagement', title, airdropId);
  },
  
  airdropComplete: (airdropId: number, title: string) => {
    trackEvent('complete_airdrop', 'conversion', title, airdropId);
  },
  
  searchPerformed: (query: string, resultsCount: number) => {
    trackEvent('search', 'engagement', query, resultsCount);
  },
  
  filterApplied: (filterType: string, filterValue: string) => {
    trackEvent('filter_applied', 'engagement', `${filterType}:${filterValue}`);
  },
  
  userRegistration: (method: 'traditional' | 'wallet') => {
    trackEvent('sign_up', 'user_acquisition', method);
  },
  
  userLogin: (method: 'traditional' | 'wallet') => {
    trackEvent('login', 'user_retention', method);
  },
  
  levelUp: (newLevel: number) => {
    trackEvent('level_up', 'gamification', `level_${newLevel}`, newLevel);
  },
  
  milestoneReached: (milestone: string) => {
    trackEvent('milestone', 'gamification', milestone);
  },
  
  shareAirdrop: (airdropId: number, platform: string) => {
    trackEvent('share', 'social', platform, airdropId);
  }
};

// Custom hook for automatic page view tracking
export const useAnalytics = () => {
  const [location] = useLocation();
  const prevLocationRef = useRef<string>(location);
  
  useEffect(() => {
    if (location !== prevLocationRef.current) {
      trackPageView(location);
      prevLocationRef.current = location;
    }
  }, [location]);
};