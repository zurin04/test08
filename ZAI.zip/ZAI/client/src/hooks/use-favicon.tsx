import { useEffect } from 'react';
import { useQuery } from '@tanstack/react-query';
import type { SiteSettings } from '@shared/schema';

export function useFavicon() {
  const { data: siteSettings } = useQuery<SiteSettings>({
    queryKey: ['/api/site-settings'],
  });

  useEffect(() => {
    const updateFavicon = () => {
      // Remove existing favicon links
      const existingFavicons = document.querySelectorAll('link[rel*="icon"]');
      existingFavicons.forEach(link => link.remove());

      // Create new favicon link
      const faviconLink = document.createElement('link');
      faviconLink.rel = 'icon';
      
      if (siteSettings?.logo_url) {
        // Use admin-uploaded logo as favicon
        faviconLink.href = siteSettings.logo_url;
        faviconLink.type = 'image/png';
      } else {
        // Fallback to default SVG favicon
        faviconLink.href = '/favicon.svg';
        faviconLink.type = 'image/svg+xml';
      }

      // Add to document head
      document.head.appendChild(faviconLink);

      // Also update shortcut icon
      const shortcutLink = document.createElement('link');
      shortcutLink.rel = 'shortcut icon';
      shortcutLink.href = faviconLink.href;
      shortcutLink.type = faviconLink.type;
      document.head.appendChild(shortcutLink);

      // Update page title with site name
      if (siteSettings?.site_name) {
        document.title = `${siteSettings.site_name} - Cryptocurrency Airdrops and Tutorials`;
      }
    };

    updateFavicon();
  }, [siteSettings]);

  return siteSettings;
}