import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { useAuth } from "@/hooks/use-auth";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  Trophy, 
  Medal, 
  Award, 
  Crown,
  TrendingUp,
  Star,
  Target,
  Zap
} from "lucide-react";

interface LeaderboardEntry {
  id: number;
  username: string;
  profileImage?: string;
  level: number;
  xp: number;
  completedAirdrops: number;
  totalPoints: number;
  streak: number;
  isCurrentUser?: boolean;
}

interface LeaderboardData {
  topUsers: LeaderboardEntry[];
  userRank?: number;
  userEntry?: LeaderboardEntry;
}

const getRankIcon = (rank: number) => {
  switch (rank) {
    case 1:
      return <Crown className="h-5 w-5 text-yellow-500" />;
    case 2:
      return <Medal className="h-5 w-5 text-gray-400" />;
    case 3:
      return <Award className="h-5 w-5 text-orange-500" />;
    default:
      return <span className="text-sm font-bold text-muted-foreground">#{rank}</span>;
  }
};

const getRankColor = (rank: number) => {
  switch (rank) {
    case 1:
      return "from-yellow-500 to-yellow-300";
    case 2:
      return "from-gray-500 to-gray-300";
    case 3:
      return "from-orange-500 to-orange-300";
    default:
      return "from-blue-500 to-blue-300";
  }
};

export default function Leaderboard() {
  const { user } = useAuth();
  const [activeTab, setActiveTab] = useState("level");

  const { data: leaderboardData, isLoading } = useQuery<LeaderboardData>({
    queryKey: ["/api/leaderboard", activeTab],
    enabled: !!user,
  });

  const getInitials = (username: string) => {
    return username.slice(0, 2).toUpperCase();
  };

  if (!user) {
    return (
      <Card>
        <CardContent className="text-center py-8">
          <Trophy className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
          <p className="text-muted-foreground">Login to view the leaderboard and compete with other users</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Trophy className="h-5 w-5 text-yellow-500" />
            <span>Community Leaderboard</span>
          </CardTitle>
          <CardDescription>
            Compete with other users and climb the ranks
          </CardDescription>
        </CardHeader>
      </Card>

      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="level" className="flex items-center space-x-1">
            <Crown className="h-3 w-3" />
            <span>Level</span>
          </TabsTrigger>
          <TabsTrigger value="xp" className="flex items-center space-x-1">
            <Star className="h-3 w-3" />
            <span>XP</span>
          </TabsTrigger>
          <TabsTrigger value="completed" className="flex items-center space-x-1">
            <Target className="h-3 w-3" />
            <span>Completed</span>
          </TabsTrigger>
          <TabsTrigger value="streak" className="flex items-center space-x-1">
            <Zap className="h-3 w-3" />
            <span>Streak</span>
          </TabsTrigger>
        </TabsList>

        <TabsContent value={activeTab} className="mt-6">
          {isLoading ? (
            <div className="text-center py-8">Loading leaderboard...</div>
          ) : leaderboardData?.topUsers ? (
            <div className="space-y-4">
              {/* Top 3 Users - Special Display */}
              <div className="grid md:grid-cols-3 gap-4 mb-6">
                {leaderboardData.topUsers.slice(0, 3).map((entry, index) => {
                  const rank = index + 1;
                  return (
                    <Card 
                      key={entry.id}
                      className={`relative overflow-hidden bg-gradient-to-br ${getRankColor(rank)} text-white`}
                    >
                      <CardHeader className="pb-2">
                        <div className="flex items-center justify-between">
                          {getRankIcon(rank)}
                          <Badge variant="secondary" className="text-black">
                            Level {entry.level}
                          </Badge>
                        </div>
                      </CardHeader>
                      <CardContent>
                        <div className="flex items-center space-x-3">
                          <Avatar className="h-12 w-12 border-2 border-white">
                            <AvatarImage src={entry.profileImage} />
                            <AvatarFallback className="bg-white text-black">
                              {getInitials(entry.username)}
                            </AvatarFallback>
                          </Avatar>
                          <div className="flex-1">
                            <h3 className="font-semibold">{entry.username}</h3>
                            <div className="text-sm opacity-90">
                              {activeTab === "level" && `Level ${entry.level}`}
                              {activeTab === "xp" && `${entry.xp.toLocaleString()} XP`}
                              {activeTab === "completed" && `${entry.completedAirdrops} completed`}
                              {activeTab === "streak" && `${entry.streak} day streak`}
                            </div>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  );
                })}
              </div>

              {/* Rest of the leaderboard */}
              {leaderboardData.topUsers.length > 3 && (
                <Card>
                  <CardContent className="p-0">
                    <div className="space-y-1">
                      {leaderboardData.topUsers.slice(3).map((entry, index) => {
                        const rank = index + 4;
                        return (
                          <div 
                            key={entry.id}
                            className={`flex items-center space-x-4 p-4 hover:bg-muted/50 transition-colors ${
                              entry.isCurrentUser ? 'bg-blue-50 dark:bg-blue-950/20 border-l-4 border-blue-500' : ''
                            }`}
                          >
                            <div className="w-8 text-center">
                              {getRankIcon(rank)}
                            </div>
                            <Avatar className="h-8 w-8">
                              <AvatarImage src={entry.profileImage} />
                              <AvatarFallback>
                                {getInitials(entry.username)}
                              </AvatarFallback>
                            </Avatar>
                            <div className="flex-1">
                              <p className={`font-medium ${entry.isCurrentUser ? 'text-blue-600 dark:text-blue-400' : ''}`}>
                                {entry.username}
                                {entry.isCurrentUser && (
                                  <Badge variant="outline" className="ml-2 text-xs">You</Badge>
                                )}
                              </p>
                            </div>
                            <div className="text-right">
                              <div className="font-medium">
                                {activeTab === "level" && `Level ${entry.level}`}
                                {activeTab === "xp" && `${entry.xp.toLocaleString()}`}
                                {activeTab === "completed" && entry.completedAirdrops}
                                {activeTab === "streak" && `${entry.streak} days`}
                              </div>
                              <div className="text-xs text-muted-foreground">
                                {activeTab === "level" && `${entry.xp.toLocaleString()} XP`}
                                {activeTab === "xp" && `Level ${entry.level}`}
                                {activeTab === "completed" && `Level ${entry.level}`}
                                {activeTab === "streak" && `Level ${entry.level}`}
                              </div>
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  </CardContent>
                </Card>
              )}

              {/* Current User Rank (if not in top users) */}
              {leaderboardData.userRank && leaderboardData.userRank > 10 && leaderboardData.userEntry && (
                <Card className="border-blue-500/50 bg-blue-50/50 dark:bg-blue-950/20">
                  <CardHeader className="pb-2">
                    <CardTitle className="text-sm flex items-center space-x-2">
                      <TrendingUp className="h-4 w-4" />
                      <span>Your Position</span>
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="flex items-center space-x-4">
                      <div className="w-8 text-center">
                        {getRankIcon(leaderboardData.userRank)}
                      </div>
                      <Avatar className="h-8 w-8">
                        <AvatarImage src={leaderboardData.userEntry.profileImage} />
                        <AvatarFallback>
                          {getInitials(leaderboardData.userEntry.username)}
                        </AvatarFallback>
                      </Avatar>
                      <div className="flex-1">
                        <p className="font-medium text-blue-600 dark:text-blue-400">
                          {leaderboardData.userEntry.username}
                        </p>
                      </div>
                      <div className="text-right">
                        <div className="font-medium">
                          {activeTab === "level" && `Level ${leaderboardData.userEntry.level}`}
                          {activeTab === "xp" && `${leaderboardData.userEntry.xp.toLocaleString()}`}
                          {activeTab === "completed" && leaderboardData.userEntry.completedAirdrops}
                          {activeTab === "streak" && `${leaderboardData.userEntry.streak} days`}
                        </div>
                        <div className="text-xs text-muted-foreground">
                          Rank #{leaderboardData.userRank}
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              )}
            </div>
          ) : (
            <Card>
              <CardContent className="text-center py-8">
                <Trophy className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
                <p className="text-muted-foreground">No leaderboard data available yet</p>
                <p className="text-sm text-muted-foreground mt-2">
                  Complete some airdrops to start competing!
                </p>
              </CardContent>
            </Card>
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
}