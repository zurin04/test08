import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { useAuth } from "@/hooks/use-auth";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  Trophy, 
  Star, 
  Target, 
  Zap, 
  CheckCircle2, 
  Crown, 
  Medal, 
  Award,
  Lock,
  Gift
} from "lucide-react";

interface Achievement {
  id: string;
  title: string;
  description: string;
  icon: string;
  category: 'participation' | 'completion' | 'social' | 'streak' | 'milestone';
  difficulty: 'bronze' | 'silver' | 'gold' | 'platinum';
  points: number;
  requirement: number;
  progress: number;
  unlocked: boolean;
  unlockedAt?: string;
  reward?: string;
}

const difficultyColors = {
  bronze: "from-orange-600 to-orange-400",
  silver: "from-gray-500 to-gray-300", 
  gold: "from-yellow-500 to-yellow-300",
  platinum: "from-purple-600 to-purple-400"
};

export default function Achievements() {
  const { user } = useAuth();
  const [selectedCategory, setSelectedCategory] = useState<string>("all");

  // Mock achievements data for now
  const achievements: Achievement[] = [
    {
      id: "first_save",
      title: "Getting Started",
      description: "Save your first airdrop",
      icon: "star",
      category: "participation",
      difficulty: "bronze",
      points: 50,
      requirement: 1,
      progress: 1,
      unlocked: true,
      unlockedAt: new Date().toISOString()
    },
    {
      id: "first_complete",
      title: "Task Master",
      description: "Complete your first airdrop",
      icon: "check",
      category: "completion",
      difficulty: "bronze",
      points: 100,
      requirement: 1,
      progress: 0,
      unlocked: false
    },
    {
      id: "complete_5",
      title: "Rising Star",
      description: "Complete 5 airdrops",
      icon: "medal",
      category: "completion",
      difficulty: "silver",
      points: 250,
      requirement: 5,
      progress: 0,
      unlocked: false
    }
  ];

  const getAchievementIcon = (iconName: string) => {
    const iconMap: { [key: string]: any } = {
      trophy: Trophy,
      star: Star,
      target: Target,
      zap: Zap,
      check: CheckCircle2,
      crown: Crown,
      medal: Medal,
      award: Award,
      gift: Gift
    };
    const IconComponent = iconMap[iconName] || Trophy;
    return <IconComponent className="h-6 w-6" />;
  };

  const filteredAchievements = selectedCategory === "all" 
    ? achievements 
    : achievements.filter(achievement => achievement.category === selectedCategory);

  const unlockedCount = achievements.filter(a => a.unlocked).length;
  const totalPoints = achievements.filter(a => a.unlocked).reduce((sum, a) => sum + a.points, 0);

  if (!user) {
    return (
      <Card>
        <CardContent className="text-center py-8">
          <Trophy className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
          <p className="text-muted-foreground">Login to view your achievements and progress</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      {/* Stats Overview */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Crown className="h-5 w-5 text-yellow-500" />
            <span>Achievement Progress</span>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
            <div className="text-center">
              <div className="text-2xl font-bold text-green-500">{unlockedCount}</div>
              <div className="text-sm text-muted-foreground">Unlocked</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-blue-500">{totalPoints}</div>
              <div className="text-sm text-muted-foreground">Points</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-purple-500">{achievements.length}</div>
              <div className="text-sm text-muted-foreground">Total</div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Achievement Categories */}
      <Tabs value={selectedCategory} onValueChange={setSelectedCategory}>
        <TabsList>
          <TabsTrigger value="all">All</TabsTrigger>
          <TabsTrigger value="participation">Participation</TabsTrigger>
          <TabsTrigger value="completion">Completion</TabsTrigger>
          <TabsTrigger value="social">Social</TabsTrigger>
          <TabsTrigger value="streak">Streak</TabsTrigger>
          <TabsTrigger value="milestone">Milestone</TabsTrigger>
        </TabsList>

        <TabsContent value={selectedCategory} className="mt-6">
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            {filteredAchievements.map((achievement) => (
              <Card 
                key={achievement.id} 
                className={`relative overflow-hidden transition-all duration-200 hover:shadow-lg ${
                  achievement.unlocked 
                    ? 'ring-2 ring-green-500/20 bg-gradient-to-br from-green-50/5 to-transparent' 
                    : 'opacity-75'
                }`}
              >
                {achievement.unlocked && (
                  <div className="absolute top-2 right-2">
                    <CheckCircle2 className="h-5 w-5 text-green-500" />
                  </div>
                )}
                {!achievement.unlocked && achievement.progress === 0 && (
                  <div className="absolute top-2 right-2">
                    <Lock className="h-4 w-4 text-muted-foreground" />
                  </div>
                )}
                
                <CardHeader className="pb-2">
                  <div className="flex items-start justify-between">
                    <div className={`p-3 rounded-full bg-gradient-to-br ${difficultyColors[achievement.difficulty]}`}>
                      {getAchievementIcon(achievement.icon)}
                    </div>
                    <Badge 
                      variant={achievement.unlocked ? "default" : "secondary"}
                      className="capitalize"
                    >
                      {achievement.difficulty}
                    </Badge>
                  </div>
                  <div>
                    <CardTitle className="text-lg">{achievement.title}</CardTitle>
                    <CardDescription className="text-sm">
                      {achievement.description}
                    </CardDescription>
                  </div>
                </CardHeader>
                
                <CardContent>
                  <div className="space-y-3">
                    {!achievement.unlocked && (
                      <div>
                        <div className="flex justify-between text-sm mb-1">
                          <span>Progress</span>
                          <span>{achievement.progress}/{achievement.requirement}</span>
                        </div>
                        <Progress 
                          value={(achievement.progress / achievement.requirement) * 100} 
                          className="h-2"
                        />
                      </div>
                    )}
                    
                    <div className="flex items-center justify-between">
                      <span className="text-sm font-medium text-muted-foreground">
                        {achievement.points} points
                      </span>
                      {achievement.reward && (
                        <Badge variant="outline" className="text-xs">
                          <Gift className="h-3 w-3 mr-1" />
                          {achievement.reward}
                        </Badge>
                      )}
                    </div>
                    
                    {achievement.unlocked && achievement.unlockedAt && (
                      <p className="text-xs text-green-600">
                        Unlocked {new Date(achievement.unlockedAt).toLocaleDateString()}
                      </p>
                    )}
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}