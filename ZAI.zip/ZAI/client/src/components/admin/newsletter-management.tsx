import React, { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Newsletter } from "@shared/schema";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Input } from "@/components/ui/input";
import { Loader2, Download, Search, X } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

export default function NewsletterManagement() {
  const { toast } = useToast();
  const [searchTerm, setSearchTerm] = useState("");
  
  const { data: subscribers, isLoading, error } = useQuery<Newsletter[]>({
    queryKey: ["/api/newsletter/subscribers"],
    retry: false
  });

  // Show toast on error
  React.useEffect(() => {
    if (error) {
      toast({
        title: "Error",
        description: `Failed to load newsletter subscribers: ${error.message}`,
        variant: "destructive",
      });
    }
  }, [error, toast]);
  
  const filteredSubscribers = React.useMemo(() => {
    if (!subscribers) return [];
    return subscribers.filter((subscriber: Newsletter) => 
      subscriber.email.toLowerCase().includes(searchTerm.toLowerCase())
    );
  }, [subscribers, searchTerm]);
  
  const handleExport = () => {
    // Create a download link for the CSV export
    window.open("/api/newsletter/export", "_blank");
  };
  
  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle className="text-2xl">Newsletter Management</CardTitle>
        <CardDescription>
          Manage newsletter subscribers and export data
        </CardDescription>
      </CardHeader>
      <CardContent>
        {isLoading ? (
          <div className="flex justify-center my-8">
            <Loader2 className="h-8 w-8 animate-spin text-primary" />
          </div>
        ) : (
          <>
            <div className="flex items-center mb-4 gap-2">
              <div className="relative flex-1">
                <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="Search subscribers..."
                  className="pl-8"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                />
                {searchTerm && (
                  <button
                    onClick={() => setSearchTerm("")}
                    className="absolute right-2 top-2.5"
                  >
                    <X className="h-4 w-4 text-muted-foreground" />
                  </button>
                )}
              </div>
              <Button 
                variant="secondary" 
                className="flex items-center gap-2"
                onClick={handleExport}
              >
                <Download className="h-4 w-4" />
                Export CSV
              </Button>
            </div>
            
            <div className="rounded-md border">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Email</TableHead>
                    <TableHead>Subscribed Date</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredSubscribers && filteredSubscribers.length > 0 ? (
                    filteredSubscribers.map((subscriber: Newsletter) => (
                      <TableRow key={subscriber.id}>
                        <TableCell>{subscriber.email}</TableCell>
                        <TableCell>
                          {new Date(subscriber.subscribed_at).toLocaleDateString()}
                        </TableCell>
                      </TableRow>
                    ))
                  ) : (
                    <TableRow>
                      <TableCell colSpan={2} className="text-center py-4">
                        {searchTerm
                          ? "No subscribers found matching your search"
                          : "No subscribers found"}
                      </TableCell>
                    </TableRow>
                  )}
                </TableBody>
              </Table>
            </div>
            
            <div className="mt-4 text-sm text-muted-foreground">
              Total subscribers: {subscribers?.length || 0}
            </div>
          </>
        )}
      </CardContent>
    </Card>
  );
}