import { useState } from "react";
import { Link, useLocation } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  Sheet,
  SheetContent,
  SheetDescription,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
} from "@/components/ui/sheet";
import NotificationSystem from "@/components/ui/notification-system";
import { ThemeToggle } from "@/components/ui/theme-toggle";
import {
  Home,
  Menu,
  Search,
  Bell,
  User,
  Settings,
  LogOut,
  Trophy,
  BarChart3,
  MessageSquare,
  Plus,
  X
} from "lucide-react";

export default function MobileNav() {
  const [location] = useLocation();
  const { user, logoutMutation } = useAuth();
  const [isOpen, setIsOpen] = useState(false);

  const handleLogout = () => {
    logoutMutation.mutate();
    setIsOpen(false);
  };

  const navItems = [
    { href: "/", icon: Home, label: "Home" },
    { href: "/airdrops", icon: Search, label: "Browse" },
    { href: "/chat", icon: MessageSquare, label: "Chat" },
    ...(user ? [
      { href: "/dashboard", icon: BarChart3, label: "Dashboard" },
      { href: "/profile", icon: User, label: "Profile" }
    ] : []),
  ];

  const isActive = (path: string) => location === path;

  return (
    <>
      {/* Mobile Top Bar */}
      <div className="md:hidden fixed top-0 left-0 right-0 z-50 bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60 border-b">
        <div className="flex items-center justify-between p-4">
          <div className="flex items-center space-x-3">
            <Sheet open={isOpen} onOpenChange={setIsOpen}>
              <SheetTrigger asChild>
                <Button variant="ghost" size="sm">
                  <Menu className="h-5 w-5" />
                </Button>
              </SheetTrigger>
              <SheetContent side="left" className="w-80">
                <SheetHeader>
                  <SheetTitle>Navigation</SheetTitle>
                  <SheetDescription>
                    Access all features and settings
                  </SheetDescription>
                </SheetHeader>
                
                <div className="mt-6 space-y-4">
                  {/* User Info */}
                  {user && (
                    <div className="p-4 bg-muted rounded-lg">
                      <div className="flex items-center justify-between">
                        <div>
                          <p className="font-medium">{user.username}</p>
                          <p className="text-sm text-muted-foreground">
                            {user.isAdmin ? "Admin" : user.isCreator ? "Creator" : "Member"}
                          </p>
                        </div>
                        <div className="flex items-center space-x-2">
                          <NotificationSystem />
                          <ThemeToggle />
                        </div>
                      </div>
                    </div>
                  )}

                  {/* Navigation Links */}
                  <nav className="space-y-2">
                    {navItems.map((item) => (
                      <Link key={item.href} href={item.href}>
                        <Button
                          variant={isActive(item.href) ? "default" : "ghost"}
                          className="w-full justify-start"
                          onClick={() => setIsOpen(false)}
                        >
                          <item.icon className="h-4 w-4 mr-3" />
                          {item.label}
                        </Button>
                      </Link>
                    ))}

                    {user && (
                      <>
                        <div className="border-t pt-2 mt-4">
                          <Link href="/settings">
                            <Button
                              variant="ghost"
                              className="w-full justify-start"
                              onClick={() => setIsOpen(false)}
                            >
                              <Settings className="h-4 w-4 mr-3" />
                              Settings
                            </Button>
                          </Link>
                          
                          <Button
                            variant="ghost"
                            className="w-full justify-start text-red-600 hover:text-red-700 hover:bg-red-50"
                            onClick={handleLogout}
                            disabled={logoutMutation.isPending}
                          >
                            <LogOut className="h-4 w-4 mr-3" />
                            Logout
                          </Button>
                        </div>
                      </>
                    )}

                    {!user && (
                      <Link href="/auth">
                        <Button
                          variant="default"
                          className="w-full"
                          onClick={() => setIsOpen(false)}
                        >
                          Login / Register
                        </Button>
                      </Link>
                    )}
                  </nav>
                </div>
              </SheetContent>
            </Sheet>
            
            <h1 className="font-bold text-lg">AirdropHub</h1>
          </div>

          {/* Quick Actions */}
          <div className="flex items-center space-x-2">
            {user && (
              <>
                <NotificationSystem />
                <Link href="/create-airdrop">
                  <Button size="sm" variant="outline">
                    <Plus className="h-4 w-4" />
                  </Button>
                </Link>
              </>
            )}
          </div>
        </div>
      </div>

      {/* Mobile Bottom Navigation */}
      <div className="md:hidden fixed bottom-0 left-0 right-0 z-50 bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60 border-t">
        <div className="grid grid-cols-5 gap-1 p-2">
          <Link href="/">
            <Button 
              variant={isActive("/") ? "default" : "ghost"} 
              size="sm" 
              className="flex-col h-auto py-2 px-1"
            >
              <Home className="h-4 w-4 mb-1" />
              <span className="text-xs">Home</span>
            </Button>
          </Link>
          
          <Link href="/airdrops">
            <Button 
              variant={isActive("/airdrops") ? "default" : "ghost"} 
              size="sm" 
              className="flex-col h-auto py-2 px-1"
            >
              <Search className="h-4 w-4 mb-1" />
              <span className="text-xs">Browse</span>
            </Button>
          </Link>
          
          <Link href="/chat">
            <Button 
              variant={isActive("/chat") ? "default" : "ghost"} 
              size="sm" 
              className="flex-col h-auto py-2 px-1"
            >
              <MessageSquare className="h-4 w-4 mb-1" />
              <span className="text-xs">Chat</span>
            </Button>
          </Link>

          {user ? (
            <>
              <Link href="/dashboard">
                <Button 
                  variant={isActive("/dashboard") ? "default" : "ghost"} 
                  size="sm" 
                  className="flex-col h-auto py-2 px-1"
                >
                  <BarChart3 className="h-4 w-4 mb-1" />
                  <span className="text-xs">Stats</span>
                </Button>
              </Link>
              
              <Link href="/profile">
                <Button 
                  variant={isActive("/profile") ? "default" : "ghost"} 
                  size="sm" 
                  className="flex-col h-auto py-2 px-1 relative"
                >
                  <User className="h-4 w-4 mb-1" />
                  <span className="text-xs">Profile</span>
                  {user.isAdmin && (
                    <Badge className="absolute -top-1 -right-1 h-4 w-4 p-0 text-xs bg-yellow-500">
                      A
                    </Badge>
                  )}
                </Button>
              </Link>
            </>
          ) : (
            <>
              <div></div>
              <Link href="/auth">
                <Button 
                  variant="default" 
                  size="sm" 
                  className="flex-col h-auto py-2 px-1"
                >
                  <User className="h-4 w-4 mb-1" />
                  <span className="text-xs">Login</span>
                </Button>
              </Link>
            </>
          )}
        </div>
      </div>

      {/* Mobile Spacing */}
      <div className="md:hidden h-16" /> {/* Top spacing */}
      <div className="md:hidden h-20" /> {/* Bottom spacing */}
    </>
  );
}