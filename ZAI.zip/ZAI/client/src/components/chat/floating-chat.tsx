import { useState, useEffect, useRef } from "react";
import { Card, CardHeader, CardTitle, CardContent, CardFooter } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { useAuth } from "@/hooks/use-auth";
import { useChat } from "@/hooks/use-chat";
import { MessageSquare, X, ChevronUp, ChevronDown, Send } from "lucide-react";
import { Link } from "wouter";

export function FloatingChat() {
  const { user } = useAuth();
  const { messages, onlineUsers, sendMessage, getUserProfileImage } = useChat();
  const [newMessage, setNewMessage] = useState("");
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const [isOpen, setIsOpen] = useState(false);
  const [lastReadMessageCount, setLastReadMessageCount] = useState(() => {
    // Initialize from localStorage or 0
    const stored = localStorage.getItem('chat_last_read_count');
    return stored ? parseInt(stored, 10) : 0;
  });
  const [guestName, setGuestName] = useState(() => {
    return `Guest_${Math.floor(Math.random() * 10000)}`;
  });
  
  // Auto-scroll to bottom on new messages
  useEffect(() => {
    if (messagesEndRef.current && isOpen) {
      messagesEndRef.current.scrollIntoView({ behavior: "smooth" });
    }
  }, [messages, isOpen]);

  // Initialize read count when messages first load and handle data consistency
  useEffect(() => {
    if (messages.length > 0) {
      const stored = localStorage.getItem('chat_last_read_count');
      const storedCount = stored ? parseInt(stored, 10) : 0;
      
      // If stored count is greater than current messages, it means messages were cleared
      // or this is a new session, so reset to current message count
      if (storedCount > messages.length) {
        const newCount = messages.length;
        setLastReadMessageCount(newCount);
        localStorage.setItem('chat_last_read_count', newCount.toString());
      } else if (lastReadMessageCount === 0 && storedCount > 0) {
        // Initialize from stored value only if we haven't set it yet
        setLastReadMessageCount(storedCount);
      }
    }
  }, [messages.length]);

  // Mark messages as read when chat is opened
  useEffect(() => {
    if (isOpen) {
      const newCount = messages.length;
      setLastReadMessageCount(newCount);
      localStorage.setItem('chat_last_read_count', newCount.toString());
    }
  }, [isOpen, messages.length]);

  // Calculate unread messages count
  const unreadCount = Math.max(0, messages.length - lastReadMessageCount);
  
  // Function to manually reset notification count
  const markAllAsRead = () => {
    const newCount = messages.length;
    setLastReadMessageCount(newCount);
    localStorage.setItem('chat_last_read_count', newCount.toString());
  };
  
  const handleSendMessage = (e: React.FormEvent) => {
    e.preventDefault();
    if (newMessage.trim()) {
      sendMessage({
        user: user ? user.username : guestName,
        message: newMessage,
        isAdmin: user?.isAdmin || false,
        isCreator: user?.isCreator || false,
      });
      setNewMessage("");
      // Mark as read when user sends a message (including the message they just sent)
      const newCount = messages.length + 1;
      setLastReadMessageCount(newCount);
      localStorage.setItem('chat_last_read_count', newCount.toString());
    }
  };

  const toggleChat = () => {
    setIsOpen(prev => {
      const newIsOpen = !prev;
      // When opening chat, mark all messages as read
      if (newIsOpen) {
        const newCount = messages.length;
        setLastReadMessageCount(newCount);
        localStorage.setItem('chat_last_read_count', newCount.toString());
      }
      return newIsOpen;
    });
  };
  
  // Function to get profile image for a user if available
  const getLocalUserProfileImage = (username: string) => {
    // If the message is from the current logged-in user
    if (user && user.username === username && user.profile_image) {
      return user.profile_image;
    }
    
    // For all other users, use the cached image from our hook
    return getUserProfileImage(username);
  };

  return (
    <div className="fixed bottom-4 left-4 z-50">
      {!isOpen ? (
        <Button 
          onClick={toggleChat} 
          className="w-12 h-12 rounded-full shadow-lg bg-primary hover:bg-primary-focus"
          aria-label="Open chat"
        >
          <MessageSquare className="h-6 w-6" />
          {unreadCount > 0 && (
            <span className="absolute -top-1 -right-1 bg-red-500 text-white rounded-full w-5 h-5 flex items-center justify-center text-xs">
              {unreadCount > 9 ? '9+' : unreadCount}
            </span>
          )}
        </Button>
      ) : (
        <Card className="w-80 md:w-96 shadow-xl border border-gray-800 animate-in slide-in-from-bottom-5 duration-300">
          <CardHeader className="border-b border-gray-700 flex flex-row items-center justify-between p-3">
            <div className="flex items-center">
              <MessageSquare className="h-5 w-5 text-primary mr-2" />
              <CardTitle className="text-base">Chat ({onlineUsers} online)</CardTitle>
              {unreadCount > 0 && (
                <span className="ml-2 text-xs text-gray-400">({unreadCount} unread)</span>
              )}
            </div>
            <div className="flex space-x-1">
              {unreadCount > 0 && (
                <Button variant="ghost" size="sm" onClick={markAllAsRead} className="h-7 w-7 p-0" title="Mark all as read">
                  <span className="text-xs">✓</span>
                </Button>
              )}
              <Button variant="ghost" size="sm" onClick={toggleChat} className="h-7 w-7 p-0">
                <ChevronDown className="h-4 w-4" />
              </Button>
              <Button variant="ghost" size="sm" onClick={toggleChat} className="h-7 w-7 p-0">
                <X className="h-4 w-4" />
              </Button>
            </div>
          </CardHeader>
          
          <CardContent className="p-0 max-h-80 overflow-y-auto">
            <div className="chat-messages p-3 space-y-3" onClick={markAllAsRead}>
              {messages.length === 0 ? (
                <div className="flex justify-center py-6">
                  <div className="text-center">
                    <MessageSquare className="h-8 w-8 mx-auto text-muted-foreground mb-2" />
                    <p className="text-muted-foreground text-sm">No messages yet</p>
                  </div>
                </div>
              ) : (
                <>
                  {messages.map((msg, index) => (
                    <div key={index} className="flex items-start text-sm">
                      <Avatar className={`h-6 w-6 mr-2 ${
                          msg.isAdmin 
                            ? "admin-avatar-lightning" 
                            : msg.isCreator 
                              ? "bg-amber-700 ring-2 ring-amber-400 ring-offset-1 ring-offset-amber-900" 
                              : msg.user === (user?.username || guestName) 
                                ? "bg-blue-600" 
                                : "bg-purple-600"
                        }`}>
                        {getLocalUserProfileImage(msg.user) && (
                          <img src={getLocalUserProfileImage(msg.user) || ''} alt={msg.user} className="h-full w-full object-cover" />
                        )}
                        {msg.isAdmin && !getLocalUserProfileImage(msg.user) && (
                          <svg xmlns="http://www.w3.org/2000/svg" className="h-3 w-3" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" />
                          </svg>
                        )}
                        {!msg.isAdmin && !getLocalUserProfileImage(msg.user) && (
                          <AvatarFallback className={`text-[10px] ${msg.isCreator ? "text-amber-200" : ""}`}>
                            {msg.user.substring(0, 2).toUpperCase()}
                          </AvatarFallback>
                        )}
                      </Avatar>
                      <div className="flex-1">
                        <div className="flex items-center mb-1">
                          <span className={`text-xs font-medium mr-1 ${msg.isCreator ? "text-amber-400" : "text-white"}`}>
                            {msg.user}
                          </span>
                          {msg.isAdmin && (
                            <Badge className="mr-1 text-[10px] py-0 h-4 bg-gradient-to-r from-blue-500 to-purple-500 text-white border-none">⚡ ADMIN</Badge>
                          )}
                          {msg.isCreator && !msg.isAdmin && (
                            <Badge className="mr-1 text-[10px] py-0 h-4 bg-amber-600 hover:bg-amber-700">CREATOR</Badge>
                          )}
                          <span className="text-[10px] text-gray-500">{new Date(msg.timestamp).toLocaleTimeString()}</span>
                        </div>
                        <p className="text-gray-300 text-xs">{msg.message}</p>
                      </div>
                    </div>
                  ))}
                  
                  <div ref={messagesEndRef} />
                </>
              )}
            </div>
          </CardContent>
          
          <CardFooter className="p-3 border-t border-gray-700">
            <form onSubmit={handleSendMessage} className="w-full">
              <div className="flex items-center">
                <Input 
                  type="text" 
                  placeholder="Type your message..." 
                  className="flex-1 bg-background border border-border h-8 text-sm"
                  value={newMessage}
                  onChange={(e) => setNewMessage(e.target.value)}
                />
                <Button type="submit" className="ml-2 h-8 w-8 p-0" disabled={!newMessage.trim()}>
                  <Send className="h-4 w-4" />
                </Button>
              </div>
              <div className="text-[10px] text-gray-500 mt-1">
                {!user ? (
                  <>
                    <span>As {guestName}</span> · <Link href="/auth" className="text-primary hover:text-blue-400">Sign in</Link>
                  </>
                ) : (
                  <span>As {user.username}</span>
                )}
              </div>
            </form>
          </CardFooter>
        </Card>
      )}
    </div>
  );
}