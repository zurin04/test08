import { Link } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { SiteSettings } from "@shared/schema";
import { Button } from "@/components/ui/button";
import { Home } from "lucide-react";

export default function LegalHeader() {
  // Fetch site settings for logo and site name
  const { data: siteSettings } = useQuery<SiteSettings>({
    queryKey: ["/api/site-settings"],
  });
  
  return (
    <header className="border-b border-gray-800 bg-background/95 backdrop-blur supports-backdrop-blur:bg-background/80">
      <div className="container flex h-14 items-center px-4">
        <div className="flex items-center space-x-2">
          <Link href="/" className="flex items-center space-x-2">
            {siteSettings?.logo_url && (
              <img 
                src={siteSettings.logo_url} 
                alt={siteSettings.site_name || "AirdropVerse"} 
                className="h-8 w-auto"
              />
            )}
            <span className="font-bold text-lg">{siteSettings?.site_name || "AirdropVerse"}</span>
          </Link>
        </div>
        
        <div className="ml-auto flex items-center gap-2">
          <Button variant="ghost" size="sm" asChild>
            <Link href="/">
              <Home className="h-4 w-4 mr-1" />
              Back to Home
            </Link>
          </Button>
        </div>
      </div>
    </header>
  );
}