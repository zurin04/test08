import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { X } from "lucide-react";
import { Button } from "@/components/ui/button";
import type { Airdrops } from "@shared/schema";

export default function AnnouncementBanner() {
  const [isVisible, setIsVisible] = useState(true);
  const [hiddenBanners, setHiddenBanners] = useState<number[]>([]);

  // Get hidden banners from localStorage on mount
  useEffect(() => {
    const hidden = localStorage.getItem('hiddenBanners');
    if (hidden) {
      setHiddenBanners(JSON.parse(hidden));
    }
  }, []);

  const { data: bannerAnnouncements = [] } = useQuery<Airdrops[]>({
    queryKey: ['/api/airdrops/banner'],
  });

  // Filter out hidden banners
  const visibleBanners = bannerAnnouncements.filter(
    banner => !hiddenBanners.includes(banner.id)
  );

  const hideBanner = (bannerId: number) => {
    const newHidden = [...hiddenBanners, bannerId];
    setHiddenBanners(newHidden);
    localStorage.setItem('hiddenBanners', JSON.stringify(newHidden));
  };

  if (!isVisible || visibleBanners.length === 0) {
    return null;
  }

  return (
    <div className="bg-gradient-to-r from-blue-600 to-purple-600 text-white shadow-md relative overflow-hidden">
      <div className="py-3">
        <div className="flex items-center justify-between max-w-7xl mx-auto px-4">
          <div className="flex-1 overflow-hidden">
            <div className="whitespace-nowrap animate-marquee">
              {visibleBanners.map((banner, index) => (
                <span key={banner.id} className="inline-block">
                  <span className="text-sm font-medium">
                    📢 {banner.title}: {banner.description.replace(/<[^>]*>/g, '').substring(0, 100)}
                    {banner.description.length > 100 ? '...' : ''}
                  </span>
                  {index < visibleBanners.length - 1 && (
                    <span className="mx-8 text-white/70">•</span>
                  )}
                </span>
              ))}
            </div>
          </div>
          
          <div className="flex items-center gap-2 ml-4">
            {visibleBanners.length > 0 && (
              <Button
                variant="ghost"
                size="sm"
                onClick={() => hideBanner(visibleBanners[0].id)}
                className="text-white hover:bg-white/20 h-6 w-6 p-0"
              >
                <X className="h-3 w-3" />
              </Button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}