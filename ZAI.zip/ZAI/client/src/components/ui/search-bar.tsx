import { useState } from "react";
import { Search, Filter, X } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

interface SearchFilters {
  query: string;
  status: string;
  category: string;
  profitLevel: string;
  sortBy: string;
}

interface SearchBarProps {
  onSearch: (filters: SearchFilters) => void;
  categories: Array<{ id: number; name: string }>;
}

export default function SearchBar({ onSearch, categories }: SearchBarProps) {
  const [filters, setFilters] = useState<SearchFilters>({
    query: "",
    status: "all",
    category: "all",
    profitLevel: "all",
    sortBy: "newest"
  });

  const [activeFilters, setActiveFilters] = useState<string[]>([]);

  const handleFilterChange = (key: keyof SearchFilters, value: string) => {
    const newFilters = { ...filters, [key]: value };
    setFilters(newFilters);
    
    // Update active filters
    const newActiveFilters = Object.entries(newFilters)
      .filter(([k, v]) => k !== "query" && v !== "all" && v !== "newest")
      .map(([k, v]) => `${k}:${v}`);
    setActiveFilters(newActiveFilters);
    
    onSearch(newFilters);
  };

  const clearFilters = () => {
    const clearedFilters = {
      query: "",
      status: "all",
      category: "all", 
      profitLevel: "all",
      sortBy: "newest"
    };
    setFilters(clearedFilters);
    setActiveFilters([]);
    onSearch(clearedFilters);
  };

  const removeFilter = (filterToRemove: string) => {
    const [key, value] = filterToRemove.split(":");
    handleFilterChange(key as keyof SearchFilters, "all");
  };

  return (
    <div className="w-full space-y-4">
      {/* Search Input */}
      <div className="relative">
        <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
        <Input
          placeholder="Search airdrops, projects, or tags..."
          value={filters.query}
          onChange={(e) => handleFilterChange("query", e.target.value)}
          className="pl-10 pr-4 h-12 text-base"
        />
      </div>

      {/* Filter Controls */}
      <div className="flex flex-wrap items-center gap-2">
        <Popover>
          <PopoverTrigger asChild>
            <Button variant="outline" size="sm" className="h-9">
              <Filter className="h-4 w-4 mr-2" />
              Filters
            </Button>
          </PopoverTrigger>
          <PopoverContent className="w-80 p-4" align="start">
            <div className="space-y-4">
              <div>
                <label className="text-sm font-medium mb-2 block">Status</label>
                <Select value={filters.status} onValueChange={(v) => handleFilterChange("status", v)}>
                  <SelectTrigger>
                    <SelectValue placeholder="All Statuses" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Statuses</SelectItem>
                    <SelectItem value="active">Active</SelectItem>
                    <SelectItem value="upcoming">Upcoming</SelectItem>
                    <SelectItem value="ended">Ended</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <label className="text-sm font-medium mb-2 block">Category</label>
                <Select value={filters.category} onValueChange={(v) => handleFilterChange("category", v)}>
                  <SelectTrigger>
                    <SelectValue placeholder="All Categories" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Categories</SelectItem>
                    {categories.map((category) => (
                      <SelectItem key={category.id} value={category.id.toString()}>
                        {category.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div>
                <label className="text-sm font-medium mb-2 block">Profit Potential</label>
                <Select value={filters.profitLevel} onValueChange={(v) => handleFilterChange("profitLevel", v)}>
                  <SelectTrigger>
                    <SelectValue placeholder="All Levels" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Levels</SelectItem>
                    <SelectItem value="high">High ($1000+)</SelectItem>
                    <SelectItem value="medium">Medium ($100-$1000)</SelectItem>
                    <SelectItem value="low">Low (Under $100)</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <label className="text-sm font-medium mb-2 block">Sort By</label>
                <Select value={filters.sortBy} onValueChange={(v) => handleFilterChange("sortBy", v)}>
                  <SelectTrigger>
                    <SelectValue placeholder="Newest First" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="newest">Newest First</SelectItem>
                    <SelectItem value="oldest">Oldest First</SelectItem>
                    <SelectItem value="views">Most Viewed</SelectItem>
                    <SelectItem value="profit">Highest Profit</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </PopoverContent>
        </Popover>

        {/* Active Filters */}
        {activeFilters.length > 0 && (
          <>
            {activeFilters.map((filter) => (
              <Badge key={filter} variant="secondary" className="h-9 px-3">
                {filter.replace(":", ": ")}
                <button
                  onClick={() => removeFilter(filter)}
                  className="ml-2 hover:text-red-500"
                >
                  <X className="h-3 w-3" />
                </button>
              </Badge>
            ))}
            <Button
              variant="ghost"
              size="sm"
              onClick={clearFilters}
              className="h-9 text-red-500 hover:text-red-600"
            >
              Clear All
            </Button>
          </>
        )}
      </div>
    </div>
  );
}