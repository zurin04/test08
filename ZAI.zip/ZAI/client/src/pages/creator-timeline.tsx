import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useParams, Link } from "wouter";
import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Separator } from "@/components/ui/separator";
import { Textarea } from "@/components/ui/textarea";
import { CalendarDays, ExternalLink, Eye, Trophy, Star, ArrowLeft, Heart, MessageCircle, Send, Trash, Twitter, MessageSquare, Hash } from "lucide-react";
import { formatDistanceToNow } from "date-fns";
import { apiRequest } from "@/lib/queryClient";
import { useAuth } from "@/hooks/use-auth";
import { useToast } from "@/hooks/use-toast";
import { useProcessedContent } from "@/utils/code-block-processor";
import type { User, Airdrops, Comment, Like } from "@shared/schema";

// Comment and Like components for each airdrop
function AirdropInteractions({ airdrop }: { airdrop: Airdrops }) {
  const [showComments, setShowComments] = useState(false);
  const [newComment, setNewComment] = useState("");
  const { user } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Fetch comments and likes for this airdrop
  const { data: commentsData, isLoading: commentsLoading } = useQuery<Comment[]>({
    queryKey: ['/api/airdrops', airdrop.id, 'comments'],
    queryFn: () => fetch(`/api/airdrops/${airdrop.id}/comments`).then(res => res.json()),
    enabled: showComments,
  });

  const { data: likesData, isLoading: likesLoading } = useQuery<{
    likes: Like[];
    count: number;
    isLiked: boolean;
  }>({
    queryKey: ['/api/airdrops', airdrop.id, 'likes'],
    queryFn: () => fetch(`/api/airdrops/${airdrop.id}/likes`).then(res => res.json()),
  });

  // Create comment mutation
  const createCommentMutation = useMutation({
    mutationFn: async (content: string) => {
      console.log('Attempting to create comment for airdrop:', airdrop.id, 'user:', user?.username, 'content:', content);
      const response = await apiRequest('POST', `/api/airdrops/${airdrop.id}/comments`, { content });
      return await response.json();
    },
    onSuccess: (data: any) => {
      console.log('Comment creation successful:', data);
      queryClient.invalidateQueries({ queryKey: ['/api/airdrops', airdrop.id, 'comments'] });
      setNewComment("");
      toast({ title: "Comment added successfully!" });
    },
    onError: (error: any) => {
      console.error('Comment creation error:', error);
      toast({ 
        title: "Error", 
        description: error.message || "Failed to add comment",
        variant: "destructive" 
      });
    }
  });

  // Delete comment mutation
  const deleteCommentMutation = useMutation({
    mutationFn: async (commentId: number) => {
      return apiRequest('DELETE', `/api/comments/${commentId}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/airdrops', airdrop.id, 'comments'] });
      toast({ title: "Comment deleted successfully!" });
    },
    onError: (error: any) => {
      toast({ 
        title: "Error", 
        description: error.message || "Failed to delete comment",
        variant: "destructive" 
      });
    }
  });

  // Toggle like mutation
  const toggleLikeMutation = useMutation({
    mutationFn: async () => {
      console.log('Attempting to toggle like for airdrop:', airdrop.id, 'user:', user?.username);
      const response = await apiRequest('POST', `/api/airdrops/${airdrop.id}/likes`);
      return await response.json();
    },
    onSuccess: (data: any) => {
      console.log('Like toggle successful:', data);
      queryClient.invalidateQueries({ queryKey: ['/api/airdrops', airdrop.id, 'likes'] });
      queryClient.refetchQueries({ queryKey: ['/api/airdrops', airdrop.id, 'likes'] });
      if (data && typeof data.isLiked !== 'undefined') {
        toast({ 
          title: data.isLiked ? "Liked!" : "Unliked!",
          description: `You ${data.isLiked ? 'liked' : 'unliked'} this airdrop`
        });
      }
    },
    onError: (error: any) => {
      console.error('Like toggle error:', error);
      toast({ 
        title: "Error", 
        description: error.message || "Failed to toggle like",
        variant: "destructive" 
      });
    }
  });

  const handleSubmitComment = () => {
    if (!newComment.trim()) return;
    createCommentMutation.mutate(newComment.trim());
  };

  const handleDeleteComment = (commentId: number) => {
    deleteCommentMutation.mutate(commentId);
  };

  function getInitials(username: string) {
    return username.substring(0, 2).toUpperCase();
  }

  return (
    <div className="space-y-4">
      {/* Like and Comment Actions */}
      <div className="flex items-center gap-4 pt-4 border-t border-gray-700">
        <Button
          variant="ghost"
          size="sm"
          onClick={() => user ? toggleLikeMutation.mutate() : toast({ title: "Please log in to like airdrops", variant: "destructive" })}
          disabled={toggleLikeMutation.isPending || likesLoading}
          className="flex items-center gap-2 text-gray-300 hover:text-red-400"
        >
          <Heart className={`w-4 h-4 ${likesData?.isLiked ? 'fill-red-400 text-red-400' : ''}`} />
          <span>{likesData?.count || 0}</span>
        </Button>
        
        <Button
          variant="ghost"
          size="sm"
          onClick={() => setShowComments(!showComments)}
          className="flex items-center gap-2 text-gray-300 hover:text-blue-400"
        >
          <MessageCircle className="w-4 h-4" />
          <span>{commentsData?.length || 0}</span>
        </Button>
      </div>

      {/* Comments Section */}
      {showComments && (
        <div className="space-y-4 bg-gray-800/30 p-4 rounded-lg border border-gray-700">
          {/* Add Comment Form */}
          {user && (
            <div className="space-y-3">
              <Textarea
                placeholder="Write a comment..."
                value={newComment}
                onChange={(e) => setNewComment(e.target.value)}
                className="bg-gray-700 border-gray-600 text-white resize-none"
                rows={3}
              />
              <Button
                size="sm"
                onClick={handleSubmitComment}
                disabled={!newComment.trim() || createCommentMutation.isPending}
                className="flex items-center gap-2"
              >
                <Send className="w-4 h-4" />
                {createCommentMutation.isPending ? "Posting..." : "Post Comment"}
              </Button>
            </div>
          )}

          {/* Comments List */}
          {commentsLoading ? (
            <div className="space-y-3">
              {[1, 2].map((i) => (
                <div key={i} className="animate-pulse space-y-2">
                  <div className="flex items-center gap-2">
                    <div className="w-8 h-8 bg-gray-600 rounded-full"></div>
                    <div className="h-4 bg-gray-600 rounded w-24"></div>
                  </div>
                  <div className="h-3 bg-gray-600 rounded w-full"></div>
                  <div className="h-3 bg-gray-600 rounded w-3/4"></div>
                </div>
              ))}
            </div>
          ) : commentsData && commentsData.length > 0 ? (
            <div className="space-y-4">
              {commentsData.map((comment: any) => (
                <div key={comment.id} className="space-y-2">
                  <div className="flex items-start justify-between">
                    <div className="flex items-center gap-2">
                      <Avatar className="w-8 h-8">
                        <AvatarImage src={comment.user?.profile_image || undefined} />
                        <AvatarFallback className="bg-gradient-to-r from-blue-500 to-purple-600 text-white text-xs">
                          {getInitials(comment.user?.username || 'User')}
                        </AvatarFallback>
                      </Avatar>
                      <div className="flex items-center gap-2">
                        <span className="font-medium text-white">{comment.user?.username || 'User'}</span>
                        {comment.user?.isCreator && (
                          <Badge variant="secondary" className="text-xs bg-yellow-600/20 text-yellow-400">
                            Creator
                          </Badge>
                        )}
                        {comment.user?.isAdmin && (
                          <Badge variant="secondary" className="text-xs bg-red-600/20 text-red-400">
                            Admin
                          </Badge>
                        )}
                        <span className="text-xs text-gray-400">
                          {formatDistanceToNow(new Date(comment.created_at), { addSuffix: true })}
                        </span>
                      </div>
                    </div>
                    
                    {user && (user.id === comment.user_id || user.isAdmin) && (
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => handleDeleteComment(comment.id)}
                        disabled={deleteCommentMutation.isPending}
                        className="text-gray-400 hover:text-red-400 p-1"
                      >
                        <Trash className="w-4 h-4" />
                      </Button>
                    )}
                  </div>
                  
                  <p className="text-gray-300 text-sm ml-10">{comment.content}</p>
                </div>
              ))}
            </div>
          ) : (
            <p className="text-gray-400 text-sm text-center py-4">
              No comments yet. {user ? "Be the first to comment!" : "Log in to comment."}
            </p>
          )}
        </div>
      )}
    </div>
  );
}

export default function CreatorTimeline() {
  const { username } = useParams();

  const { data: creator, isLoading: creatorLoading } = useQuery<User>({
    queryKey: ['/api/users/creator', username],
    queryFn: () => fetch(`/api/users/creator/${username}`).then(res => res.json()),
    enabled: !!username,
  });

  const { data: airdrops, isLoading: airdropsLoading } = useQuery<Airdrops[]>({
    queryKey: ['/api/airdrops/creator', username],
    queryFn: () => fetch(`/api/airdrops/creator/${username}`).then(res => res.json()),
    enabled: !!username,
  });

  const { data: stats } = useQuery<{
    totalAirdrops: number;
    totalViews: number;
    avgViews: number;
    joinedDate: string;
  }>({
    queryKey: ['/api/users/creator/stats', username],
    queryFn: () => fetch(`/api/users/creator/stats/${username}`).then(res => res.json()),
    enabled: !!username,
  });

  if (creatorLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-gray-900 via-gray-800 to-black">
        <div className="container mx-auto px-4 py-8">
          <div className="animate-pulse space-y-6">
            <div className="h-48 bg-gray-700 rounded-lg"></div>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {[1, 2, 3].map((i) => (
                <div key={i} className="h-32 bg-gray-700 rounded-lg"></div>
              ))}
            </div>
          </div>
        </div>
      </div>
    );
  }

  if (!creator || (!creator.isCreator && !creator.isAdmin)) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-gray-900 via-gray-800 to-black flex items-center justify-center">
        <Card className="max-w-md w-full mx-4 bg-gray-800/50 border-gray-700">
          <CardContent className="p-6 text-center">
            <h2 className="text-xl font-bold text-white mb-2">Creator Not Found</h2>
            <p className="text-gray-400 mb-4">
              This user doesn't exist or isn't a verified creator.
            </p>
            <Link href="/members">
              <Button>Browse All Members</Button>
            </Link>
          </CardContent>
        </Card>
      </div>
    );
  }

  function getInitials(username: string) {
    return username.slice(0, 2).toUpperCase();
  }

  const isLoading = airdropsLoading;

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-gray-800 to-black">
      <div className="container mx-auto px-4 py-8">
        {/* Back Button */}
        <div className="mb-6">
          <Link href="/">
            <Button variant="ghost" className="text-gray-300 hover:text-white">
              <ArrowLeft className="h-4 w-4 mr-2" />
              Back to Home
            </Button>
          </Link>
        </div>

        {/* Creator Profile Header */}
        <Card className={`mb-8 relative overflow-hidden ${creator.isAdmin ? 'admin-lightning-border bg-gradient-to-r from-gray-800/70 to-gray-900/70' : 'bg-gradient-to-r from-gray-800/50 to-gray-900/50 border-gray-700'}`}>
          {creator.isAdmin && (
            <div className="absolute inset-0 bg-gradient-to-br from-blue-500/5 via-purple-500/5 to-cyan-500/5 pointer-events-none"></div>
          )}
          <CardContent className="p-8 relative z-10">
            <div className="flex flex-col md:flex-row items-start gap-6">
              <Avatar className={`h-24 w-24 border-4 ${creator.isAdmin ? 'admin-avatar-lightning' : 'border-primary/20'}`}>
                <AvatarImage src={creator.profile_image || undefined} />
                <AvatarFallback className={`text-2xl ${creator.isAdmin ? 'bg-gradient-to-br from-blue-500/30 to-purple-500/30 text-blue-200' : 'bg-gradient-to-br from-primary/20 to-primary/40'}`}>
                  {getInitials(creator.username)}
                </AvatarFallback>
              </Avatar>
              
              <div className="flex-1">
                <div className="flex items-center gap-3 mb-3">
                  <h1 className={`text-3xl font-bold ${creator.isAdmin ? 'bg-gradient-to-r from-blue-300 to-purple-300 bg-clip-text text-transparent' : 'text-white'}`}>
                    {creator.username}
                  </h1>
                  {creator.isAdmin ? (
                    <Badge className="bg-gradient-to-r from-blue-500 to-purple-500 text-white border-none shadow-lg">
                      <Trophy className="h-3 w-3 mr-1" />
                      ⚡ ADMIN
                    </Badge>
                  ) : (
                    <Badge className="bg-gradient-to-r from-yellow-500/20 to-yellow-600/20 text-yellow-400 border-yellow-500/30">
                      <Trophy className="h-3 w-3 mr-1" />
                      Creator
                    </Badge>
                  )}
                </div>
                
                {creator.bio && (
                  <p className="text-gray-300 text-lg mb-4">{creator.bio}</p>
                )}
                
                <div className="space-y-3">
                  <div className="flex items-center gap-1 text-sm text-gray-400">
                    <CalendarDays className="h-4 w-4" />
                    Joined {formatDistanceToNow(new Date(creator.created_at))} ago
                  </div>
                  
                  {/* Social Media Links */}
                  {(creator.twitter_handle || creator.discord_handle || creator.telegram_handle) && (
                    <div className="space-y-2">
                      <h4 className="text-sm font-medium text-gray-300">Connect with {creator.username}</h4>
                      <div className="flex flex-wrap gap-3">
                        {creator.twitter_handle && (
                          <a 
                            href={`https://twitter.com/${creator.twitter_handle}`}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-blue-500/10 border border-blue-500/20 hover:bg-blue-500/20 transition-colors group"
                          >
                            <Twitter className="h-4 w-4 text-blue-400" />
                            <span className="text-sm text-blue-400 group-hover:text-blue-300">@{creator.twitter_handle}</span>
                          </a>
                        )}
                        
                        {creator.discord_handle && (
                          <a 
                            href={`https://discord.com/users/${creator.discord_handle}`}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-indigo-500/10 border border-indigo-500/20 hover:bg-indigo-500/20 transition-colors group"
                          >
                            <MessageSquare className="h-4 w-4 text-indigo-400" />
                            <span className="text-sm text-indigo-400 group-hover:text-indigo-300">{creator.discord_handle}</span>
                          </a>
                        )}
                        
                        {creator.telegram_handle && (
                          <a 
                            href={`https://t.me/${creator.telegram_handle}`}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-cyan-500/10 border border-cyan-500/20 hover:bg-cyan-500/20 transition-colors group"
                          >
                            <Hash className="h-4 w-4 text-cyan-400" />
                            <span className="text-sm text-cyan-400 group-hover:text-cyan-300">@{creator.telegram_handle}</span>
                          </a>
                        )}
                      </div>
                    </div>
                  )}
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <Card className="bg-gradient-to-br from-blue-500/10 to-blue-600/10 border-blue-500/20">
            <CardContent className="p-6 text-center">
              <div className="text-3xl font-bold text-blue-400 mb-2">{stats?.totalAirdrops || 0}</div>
              <div className="text-sm text-gray-400">Total Airdrops</div>
            </CardContent>
          </Card>
          
          <Card className="bg-gradient-to-br from-green-500/10 to-green-600/10 border-green-500/20">
            <CardContent className="p-6 text-center">
              <div className="text-3xl font-bold text-green-400 mb-2">{stats?.totalViews?.toLocaleString() || 0}</div>
              <div className="text-sm text-gray-400">Total Views</div>
            </CardContent>
          </Card>
          
          <Card className="bg-gradient-to-br from-purple-500/10 to-purple-600/10 border-purple-500/20">
            <CardContent className="p-6 text-center">
              <div className="text-3xl font-bold text-purple-400 mb-2">{stats ? Math.round(stats.avgViews) : 0}</div>
              <div className="text-sm text-gray-400">Avg Views</div>
            </CardContent>
          </Card>
          
          <Card className="bg-gradient-to-br from-yellow-500/10 to-yellow-600/10 border-yellow-500/20">
            <CardContent className="p-6 text-center">
              <div className="text-3xl font-bold text-yellow-400 mb-2">
                {formatDistanceToNow(new Date(creator.created_at)).replace(' ago', '')}
              </div>
              <div className="text-sm text-gray-400">Creator Since</div>
            </CardContent>
          </Card>
        </div>

        {/* Timeline Header */}
        <div className={`flex items-center justify-between mb-6 p-4 rounded-lg ${
          creator.isAdmin 
            ? 'bg-gradient-to-r from-blue-500/10 to-purple-500/10 admin-lightning-border' 
            : 'bg-gradient-to-r from-yellow-500/10 to-amber-500/10 border-2 border-yellow-500/40 shadow-lg shadow-yellow-500/20'
        }`}>
          <h2 className={`text-2xl font-bold ${
            creator.isAdmin 
              ? 'bg-gradient-to-r from-blue-300 to-purple-300 bg-clip-text text-transparent' 
              : 'bg-gradient-to-r from-yellow-300 to-amber-300 bg-clip-text text-transparent'
          }`}>
            {creator.isAdmin ? '⚡ Admin Timeline' : '🏆 Creator Timeline'}
          </h2>
          <div className={`text-sm font-medium ${
            creator.isAdmin ? 'text-blue-300' : 'text-yellow-300'
          }`}>
            {airdrops?.length || 0} airdrops posted
          </div>
        </div>

        {/* Timeline Content */}
        {isLoading ? (
          <div className="space-y-6">
            {[1, 2, 3].map((i) => (
              <Card key={i} className="bg-gray-800/50 border-gray-700">
                <CardContent className="p-6">
                  <div className="animate-pulse space-y-3">
                    <div className="h-4 bg-gray-700 rounded w-3/4"></div>
                    <div className="h-3 bg-gray-700 rounded w-1/2"></div>
                    <div className="h-20 bg-gray-700 rounded"></div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        ) : airdrops && airdrops.length > 0 ? (
          <div className="space-y-6">
            {airdrops.map((airdrop, index) => (
              <Card key={airdrop.id} className={`relative overflow-hidden transition-all duration-300 hover:scale-[1.02] ${
                creator.isAdmin 
                  ? 'bg-gradient-to-br from-gray-800/70 to-gray-900/70 admin-lightning-border hover:shadow-blue-500/30' 
                  : 'bg-gradient-to-br from-gray-800/50 to-gray-900/50 border-2 border-yellow-500/40 hover:border-yellow-400/60 shadow-lg shadow-yellow-500/20 hover:shadow-yellow-500/30'
              }`}>
                {creator.isAdmin && (
                  <div className="absolute top-0 right-0 w-16 h-16 bg-gradient-to-br from-blue-500/20 to-purple-500/20 transform rotate-45 translate-x-8 -translate-y-8"></div>
                )}
                {!creator.isAdmin && (
                  <div className="absolute top-0 right-0 w-16 h-16 bg-gradient-to-br from-yellow-500/10 to-amber-500/10 transform rotate-45 translate-x-8 -translate-y-8"></div>
                )}
                <CardContent className="p-6 relative z-10">
                  <div className="flex items-start justify-between mb-4">
                    <div className="flex-1">
                      <div className="flex items-center gap-3 mb-2">
                        <Link href={`/airdrops/${airdrop.id}`}>
                          <h3 className={`text-xl font-semibold transition-colors cursor-pointer ${
                            creator.isAdmin 
                              ? 'bg-gradient-to-r from-blue-300 to-purple-300 bg-clip-text text-transparent hover:from-blue-200 hover:to-purple-200' 
                              : 'text-white hover:text-yellow-400'
                          }`}>
                            {airdrop.title}
                          </h3>
                        </Link>
                        {index === 0 && (
                          <Badge className="bg-gradient-to-r from-green-500/20 to-green-600/20 text-green-400 border-green-500/30">
                            Latest
                          </Badge>
                        )}
                      </div>
                      
                      <div className="flex items-center gap-4 text-sm text-gray-400 mb-3">
                        <div className="flex items-center gap-1">
                          <CalendarDays className="h-4 w-4" />
                          {formatDistanceToNow(new Date(airdrop.created_at))} ago
                        </div>
                        <div className="flex items-center gap-1">
                          <Eye className="h-4 w-4" />
                          {airdrop.views} views
                        </div>
                        {airdrop.potential_profit && (
                          <Badge variant="outline" className="text-green-400 border-green-500/30">
                            {airdrop.potential_profit}
                          </Badge>
                        )}
                      </div>
                    </div>
                  </div>

                  <div 
                    className="text-gray-300 mb-4 prose prose-invert prose-sm max-w-none line-clamp-3 prose-headings:text-white prose-p:text-gray-300 prose-a:text-blue-400 prose-strong:text-white"
                    dangerouslySetInnerHTML={{ __html: useProcessedContent(airdrop.description) }}
                  />

                  {airdrop.tags && airdrop.tags.length > 0 && (
                    <div className="flex flex-wrap gap-2 mb-4">
                      {airdrop.tags.map((tag, tagIndex) => (
                        <Badge key={tagIndex} variant="secondary" className="text-xs">
                          {tag}
                        </Badge>
                      ))}
                    </div>
                  )}

                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <Link href={`/airdrop/${airdrop.id}`}>
                        <Button size="sm">
                          View Details
                          <ExternalLink className="h-4 w-4 ml-2" />
                        </Button>
                      </Link>
                    </div>
                    
                    <Badge 
                      className={`${
                        airdrop.status === 'active' 
                          ? 'bg-green-500/20 text-green-400 border-green-500/30' 
                          : 'bg-gray-500/20 text-gray-400 border-gray-500/30'
                      }`}
                    >
                      {airdrop.status}
                    </Badge>
                  </div>

                  {/* Comments and Likes Interaction */}
                  <AirdropInteractions airdrop={airdrop} />
                </CardContent>
              </Card>
            ))}
          </div>
        ) : (
          <Card className={`relative overflow-hidden ${
            creator.isAdmin 
              ? 'bg-gradient-to-br from-gray-800/70 to-gray-900/70 admin-lightning-border' 
              : 'bg-gradient-to-br from-gray-800/50 to-gray-900/50 border-2 border-yellow-500/40 shadow-lg shadow-yellow-500/20'
          }`}>
            {creator.isAdmin && (
              <div className="absolute inset-0 bg-gradient-to-br from-blue-500/5 via-purple-500/5 to-cyan-500/5 pointer-events-none"></div>
            )}
            <CardContent className="p-12 text-center relative z-10">
              {creator.isAdmin ? (
                <div className="flex justify-center mb-6">
                  <div className="relative">
                    <Star className="h-16 w-16 text-blue-400 mx-auto admin-avatar-lightning rounded-full p-2" />
                    <div className="absolute -top-1 -right-1 text-2xl">⚡</div>
                  </div>
                </div>
              ) : (
                <Star className="h-16 w-16 text-yellow-400 mx-auto mb-6" />
              )}
              
              <h3 className={`text-xl font-semibold mb-2 ${
                creator.isAdmin 
                  ? 'bg-gradient-to-r from-blue-300 to-purple-300 bg-clip-text text-transparent' 
                  : 'text-white'
              }`}>
                No Airdrops Yet
              </h3>
              <p className="text-gray-400 mb-6">
                {creator.username} hasn't posted any airdrops yet, but they're a {creator.isAdmin ? 'verified admin' : 'verified creator'}!
              </p>
              
              {/* Creator Information */}
              <div className={`p-6 rounded-lg border max-w-md mx-auto ${
                creator.isAdmin 
                  ? 'bg-gradient-to-br from-blue-500/10 to-purple-500/10 border-blue-500/30' 
                  : 'bg-gray-700/30 border-gray-600'
              }`}>
                <h4 className={`text-lg font-medium mb-3 ${
                  creator.isAdmin 
                    ? 'bg-gradient-to-r from-blue-300 to-purple-300 bg-clip-text text-transparent' 
                    : 'text-white'
                }`}>
                  About {creator.username}
                </h4>
                <div className="space-y-3 text-sm">
                  <div className="flex items-center justify-between">
                    <span className="text-gray-400">Status:</span>
                    {creator.isAdmin ? (
                      <Badge className="bg-gradient-to-r from-blue-500 to-purple-500 text-white border-none shadow-lg">
                        <Trophy className="h-3 w-3 mr-1" />
                        ⚡ ADMIN
                      </Badge>
                    ) : (
                      <Badge className="bg-gradient-to-r from-yellow-500/20 to-yellow-600/20 text-yellow-400 border-yellow-500/30">
                        <Trophy className="h-3 w-3 mr-1" />
                        Verified Creator
                      </Badge>
                    )}
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-gray-400">Member since:</span>
                    <span className="text-white">{formatDistanceToNow(new Date(creator.created_at))} ago</span>
                  </div>
                  {creator.bio && (
                    <div className="pt-2 border-t border-gray-600">
                      <p className="text-gray-300 text-left">{creator.bio}</p>
                    </div>
                  )}
                </div>
              </div>
              
              <p className="text-gray-500 text-sm mt-6">
                Follow their social media links above to stay updated on their crypto activities!
              </p>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}